var data = {
  'GOOD': ['JOHN', 'MARY'],
  'BAD': ['DON', 'DAWN']
}

module.exports = data